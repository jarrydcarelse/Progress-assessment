import React from "react";

function Home() {
  return (
    <div className="container mt-4">
      <h1>Welcome to Boxing World</h1>
      <p>
        Experience the thrill of boxing with us. Learn about the history,
        techniques, and champions of the sport.
      </p>
      <div className="row">
        <div className="col-md-6">
          <h2>About Boxing</h2>
          <p>
            Boxing is a combat sport where two opponents engage in a contest of
            strength, speed, reflexes, endurance, and will. It is a noble art
            that requires discipline and dedication.
          </p>
          <p>
            Boxing has a rich history dating back thousands of years. It has
            produced legendary champions and iconic moments that have captured
            the hearts of millions around the world.
          </p>
          <button className="btn btn-primary">Learn More</button>
        </div>
        <div className="col-md-6">
          <img
            src="https://images.unsplash.com/photo-1591117207239-788bf8de6c3b?q=80&w=3273&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="Boxing"
            className="img-fluid mt-3"
          />
        </div>
      </div>
      <hr />
      <div>
        <h3>Boxing Legends</h3>
        <div className="row">
          <div className="col-md-4">
            <img
              src="https://www.trbimg.com/img-57523524/turbine/la-muhammad-ali-vs-sonny-liston-1965-world-heavyweight-title-20160603/"
              alt="Muhammad Ali"
              className="img-fluid rounded-circle"
            />
            <h4>Muhammad Ali</h4>
            <p>
              Considered one of the greatest heavyweight boxers of all time,
              Muhammad Ali transcended the sport with his charisma, skill, and
              activism.
            </p>
          </div>
          <div className="col-md-4">
            <img
              src="https://ca-times.brightspotcdn.com/dims4/default/1f2280e/2147483647/strip/true/crop/3072x1595+0+493/resize/1200x623!/quality/75/?url=https%3A%2F%2Fcalifornia-times-brightspot.s3.amazonaws.com%2Fa9%2F11%2Fc810a13245c39e5075343bfa688d%2Fla-sp-vegas-boxing-11.jpg"
              alt="Mike Tyson"
              className="img-fluid rounded-circle"
            />
            <h4>Mike Tyson</h4>
            <p>
              Known for his ferocious style and knockout power, Mike Tyson
              became the youngest heavyweight champion in history.
            </p>
          </div>
          <div className="col-md-4">
            <img
              src="https://a57.foxnews.com/static.foxnews.com/foxnews.com/content/uploads/2023/04/1200/675/gervonta-win.jpg?ve=1&tl=1"
              alt="Tank"
              className="img-fluid rounded-circle"
            />
            <h4>Gervonta "Tank" Davis</h4>
            <p>
              Gervonta "Tank" Davis is renowned for his ferocious punching
              power, lightning-fast hand speed, and aggressive fighting style.
              Nicknamed "Tank" for his uncompromising approach to each bout,
              Davis has gained widespread acclaim for his ability to deliver
              devastating knockouts, often within the early rounds of a fight.
              His precision, coupled with exceptional footwork and defensive
              skills, makes him a formidable opponent in the ring. Davis is also
              celebrated for his rapid ascent in the boxing world, capturing
              multiple world championships in the lightweight and super
              featherweight divisions at a remarkably young age. His
              electrifying performances and unwavering determination have
              solidified his status as one of the most exciting and promising
              talents in the sport of boxing today.
            </p>
          </div>
          
      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <p>© 2024 Boxing World. All rights reserved.</p>
        </div>
      </footer>
   
        </div>
      </div>
    </div>
  );
}

export default Home;
