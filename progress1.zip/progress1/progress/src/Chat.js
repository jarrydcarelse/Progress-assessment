import React, { useEffect } from 'react';
import Chart from 'chart.js/auto';

function Chat() {
  useEffect(() => {
    // Code to create 5 different types of charts using Chart.js
    const lineChartCanvasA = document.getElementById('lineChartA');
    const barChartCanvasA = document.getElementById('barChartA');
    const doughnutChartCanvasA = document.getElementById('doughnutChartA');
    const radarChartCanvasA = document.getElementById('radarChartA');
    const polarAreaChartCanvasA = document.getElementById('polarAreaChartA');
    const lineChartCanvasB = document.getElementById('lineChartB');
    const barChartCanvasB = document.getElementById('barChartB');
    const doughnutChartCanvasB = document.getElementById('doughnutChartB');
    const radarChartCanvasB = document.getElementById('radarChartB');
    const polarAreaChartCanvasB = document.getElementById('polarAreaChartB');
    
    // Check if the canvas is already in use
    if (lineChartCanvasA && barChartCanvasA && doughnutChartCanvasA && radarChartCanvasA && polarAreaChartCanvasA && lineChartCanvasB && barChartCanvasB && doughnutChartCanvasB && radarChartCanvasB && polarAreaChartCanvasB) {
      // If the canvas is in use, destroy the previous charts
      const lineChartContextA = lineChartCanvasA.getContext('2d');
      const barChartContextA = barChartCanvasA.getContext('2d');
      const doughnutChartContextA = doughnutChartCanvasA.getContext('2d');
      const radarChartContextA = radarChartCanvasA.getContext('2d');
      const polarAreaChartContextA = polarAreaChartCanvasA.getContext('2d');
      const lineChartContextB = lineChartCanvasB.getContext('2d');
      const barChartContextB = barChartCanvasB.getContext('2d');
      const doughnutChartContextB = doughnutChartCanvasB.getContext('2d');
      const radarChartContextB = radarChartCanvasB.getContext('2d');
      const polarAreaChartContextB = polarAreaChartCanvasB.getContext('2d');
      
      [lineChartContextA, barChartContextA, doughnutChartContextA, radarChartContextA, polarAreaChartContextA, lineChartContextB, barChartContextB, doughnutChartContextB, radarChartContextB, polarAreaChartContextB].forEach(context => {
        const existingChart = Chart.getChart(context);
        if (existingChart) {
          existingChart.destroy();
        }
      });

      // Create Polar Area chart for Boxer A
      new Chart(polarAreaChartContextA, {
        type: 'polarArea',
        data: {
          labels: ['Left Hook', 'Right Hook', 'Left Uppercut', 'Right Uppercut'],
          datasets: [{
            label: 'Power Shots',
            data: [20, 25, 15, 30],
            backgroundColor: [
              'rgba(128, 0, 0, 0.5)', // Dark red
              'rgba(0, 128, 0, 0.5)', // Dark green
              'rgba(128, 128, 0, 0.5)', // Dark yellow
              'rgba(0, 0, 128, 0.5)', // Dark blue
            ],
            borderColor: [
              'rgba(128, 0, 0, 1)', // Dark red
              'rgba(0, 128, 0, 1)', // Dark green
              'rgba(128, 128, 0, 1)', // Dark yellow
              'rgba(0, 0, 128, 1)', // Dark blue
            ],
            borderWidth: 1,
          }],
        },
      });

      // Create Radar chart for Boxer A
      new Chart(radarChartContextA, {
        type: 'radar',
        data: {
          labels: ['Speed', 'Power', 'Endurance', 'Defense', 'Agility'],
          datasets: [{
            label: 'Boxer Skills',
            data: [80, 70, 85, 75, 90],
            backgroundColor: 'rgba(0, 128, 0, 0.5)', // Dark green
            borderColor: 'rgba(0, 128, 0, 1)', // Dark green
            borderWidth: 1,
          }],
        },
        options: {
          scale: {
            ticks: {
              suggestedMin: 0,
              suggestedMax: 100,
            },
          },
        },
      });

      // Create Doughnut chart for Boxer A
      new Chart(doughnutChartContextA, {
        type: 'doughnut',
        data: {
          labels: ['Jabs', 'Hooks', 'Uppercuts'],
          datasets: [{
            label: 'Punches',
            data: [30, 40, 20],
            backgroundColor: [
              'rgba(128, 0, 0, 0.5)', // Dark red
              'rgba(0, 0, 128, 0.5)', // Dark blue
              'rgba(128, 128, 0, 0.5)', // Dark yellow
            ],
            borderColor: [
              'rgba(128, 0, 0, 1)', // Dark red
              'rgba(0, 0, 128, 1)', // Dark blue
              'rgba(128, 128, 0, 1)', // Dark yellow
            ],
            borderWidth: 1,
          }],
        },
      });

      // Create Bar chart for Boxer A
      new Chart(barChartContextA, {
        type: 'bar',
        data: {
          labels: ['Knockouts', 'Wins', 'Losses', 'Draws'],
          datasets: [{
            label: 'Boxer A',
            data: [10, 20, 5, 1],
            backgroundColor: 'rgba(128, 0, 0, 0.5)', // Dark red
            borderColor: 'rgba(128, 0, 0, 1)', // Dark red
            borderWidth: 1,
          }],
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true,
              },
            }],
          },
        },
      });

      // Create Line chart for Boxer A
      new Chart(lineChartContextA, {
        type: 'line',
        data: {
          labels: ['Round 1', 'Round 2', 'Round 3', 'Round 4', 'Round 5'],
          datasets: [{
            label: 'Boxer A',
            data: [10, 9, 8, 7, 6],
            borderColor: 'rgba(128, 0, 0, 1)', // Dark red
            borderWidth: 2,
          }],
        },
      });

      // Create Polar Area chart for Boxer B
      new Chart(polarAreaChartContextB, {
        type: 'polarArea',
        data: {
          labels: ['Left Hook', 'Right Hook', 'Left Uppercut', 'Right Uppercut'],
          datasets: [{
            label: 'Power Shots',
            data: [25, 20, 30, 15],
            backgroundColor: [
              'rgba(128, 0, 0, 0.5)', // Dark red
              'rgba(0, 128, 0, 0.5)', // Dark green
              'rgba(128, 128, 0, 0.5)', // Dark yellow
              'rgba(0, 0, 128, 0.5)', // Dark blue
            ],
            borderColor: [
              'rgba(128, 0, 0, 1)', // Dark red
              'rgba(0, 128, 0, 1)', // Dark green
              'rgba(128, 128, 0, 1)', // Dark yellow
              'rgba(0, 0, 128, 1)', // Dark blue
            ],
            borderWidth: 1,
          }],
        },
      });

      // Create Radar chart for Boxer B
      new Chart(radarChartContextB, {
        type: 'radar',
        data: {
          labels: ['Speed', 'Power', 'Endurance', 'Defense', 'Agility'],
          datasets: [{
            label: 'Boxer Skills',
            data: [70, 80, 75, 85, 90],
            backgroundColor: 'rgba(0, 128, 0, 0.5)', // Dark green
            borderColor: 'rgba(0, 128, 0, 1)', // Dark green
            borderWidth: 1,
          }],
        },
        options: {
          scale: {
            ticks: {
              suggestedMin: 0,
              suggestedMax: 100,
            },
          },
        },
      });

      // Create Doughnut chart for Boxer B
      new Chart(doughnutChartContextB, {
        type: 'doughnut',
        data: {
          labels: ['Jabs', 'Hooks', 'Uppercuts'],
          datasets: [{
            label: 'Punches',
            data: [40, 30, 25],
            backgroundColor: [
              'rgba(128, 0, 0, 0.5)', // Dark red
              'rgba(0, 0, 128, 0.5)', // Dark blue
              'rgba(128, 128, 0, 0.5)', // Dark yellow
            ],
            borderColor: [
              'rgba(128, 0, 0, 1)', // Dark red
              'rgba(0, 0, 128, 1)', // Dark blue
              'rgba(128, 128, 0, 1)', // Dark yellow
            ],
            borderWidth: 1,
          }],
        },
      });

      // Create Bar chart for Boxer B
      new Chart(barChartContextB, {
        type: 'bar',
        data: {
          labels: ['Knockouts', 'Wins', 'Losses', 'Draws'],
          datasets: [{
            label: 'Boxer B',
            data: [15, 18, 7, 2],
            backgroundColor: 'rgba(0, 0, 128, 0.5)', // Dark blue
            borderColor: 'rgba(0, 0, 128, 1)', // Dark blue
            borderWidth: 1,
          }],
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true,
              },
            }],
          },
        },
      });

      // Create Line chart for Boxer B
      new Chart(lineChartContextB, {
        type: 'line',
        data: {
          labels: ['Round 1', 'Round 2', 'Round 3', 'Round 4', 'Round 5'],
          datasets: [{
            label: 'Boxer B',
            data: [9, 8, 7, 6, 5],
            borderColor: 'rgba(0, 0, 128, 1)', // Dark blue
            borderWidth: 2,
          }],
        },
      });
    }
  }, []);

  return (
    <div className="container mt-4">
      <h1>Boxing Chat</h1>
      <div>
        <div className="chart-row">
          <div className="chart-container">
            <canvas id="lineChartA" width="400" height="200"></canvas>
            <p>Boxer A's performance over 5 rounds</p>
          </div>
          <div className="chart-container">
            <canvas id="lineChartB" width="400" height="200"></canvas>
            <p>Boxer B's performance over 5 rounds</p>
          </div>
        </div>
        <div className="chart-row">
          <div className="chart-container">
            <canvas id="barChartA" width="400" height="200"></canvas>
            <p>Boxer A's career statistics</p>
          </div>
          <div className="chart-container">
            <canvas id="barChartB" width="400" height="200"></canvas>
            <p>Boxer B's career statistics</p>
          </div>
        </div>
        <div className="chart-row">
          <div className="chart-container">
            <canvas id="doughnutChartA" width="400" height="200"></canvas>
            <p>Boxer A's distribution of punch types</p>
          </div>
          <div className="chart-container">
            <canvas id="doughnutChartB" width="400" height="200"></canvas>
            <p>Boxer B's distribution of punch types</p>
          </div>
        </div>
        <div className="chart-row">
          <div className="chart-container">
            <canvas id="radarChartA" width="400" height="200"></canvas>
            <p>Boxer A's skills across different attributes</p>
          </div>
          <div className="chart-container">
            <canvas id="radarChartB" width="400" height="200"></canvas>
            <p>Boxer B's skills across different attributes</p>
          </div>
        </div>
        <div className="chart-row">
          <div className="chart-container">
            <canvas id="polarAreaChartA" width="400" height="200"></canvas>
            <p>Boxer A's distribution of power shots</p>
          </div>
          <div className="chart-container">
            <canvas id="polarAreaChartB" width="400" height="200"></canvas>
            <p>Boxer B's distribution of power shots</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Chat;
