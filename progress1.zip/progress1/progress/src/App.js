import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './Home';
import Chat from './Chat';


function App() {
  // Render application router
  return (
    <Router>
      <div className="container"> {/* Container for layout */}
        <nav className="navbar navbar-expand-lg navbar-light bg-light mb-3"> {/* Navigation bar */}
          <Link className="navbar-brand" to="/">Boxing World</Link> {/* Link to home page */}
          <div className="collapse navbar-collapse" id="navbarNav"> {/* Collapsible navigation links */}
            <ul className="navbar-nav"> {/* List of navigation links */}
              <li className="nav-item"> {/* Individual navigation link */}
                <Link className="nav-link" to="/">Home</Link> {/* Link to home page */}
              </li>
              <li className="nav-item"> {/* Individual navigation link */}
                <Link className="nav-link" to="/chat">Chat</Link> {/* Link to chat page */}
              </li>
            </ul>
          </div>
        </nav>
 
        <Routes> {/* Define application routes */}
          <Route path="/" element={<Home />} /> {/* Route to home page */}
          <Route path="/chat" element={<Chat />} /> {/* Route to chat page */}
        </Routes>
      </div>
    </Router>
  );
 }

export default App;
